# Serial port used in the computer
# used by the Iot device
serial_port = 'COM4'

# How many loops does the
# sensor capture data
number_of_loops: int = 0
